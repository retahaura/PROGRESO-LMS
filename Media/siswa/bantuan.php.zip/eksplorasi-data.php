<?php
include '../dbconn/dbconn.php';
session_start();
if (!isset($_SESSION['id_user']) || $_SESSION['role'] != 'siswa') {
    header("Location: ../index.php");
    exit();
}
$id_siswa = $_SESSION['id_user'];
$id_materi = $_GET['id_materi'];

// Ambil semua jawaban siswa dalam array
$query_jawaban = "SELECT * FROM jawaban_data
                  WHERE id_materi = ? AND id_user = ?";
$stmt_jawaban = mysqli_prepare($conn, $query_jawaban);
mysqli_stmt_bind_param($stmt_jawaban, 'ii', $id_materi, $id_siswa);
mysqli_stmt_execute($stmt_jawaban);
$result_jawaban = mysqli_stmt_get_result($stmt_jawaban);

$jawaban = [];
while ($row_j = mysqli_fetch_assoc($result_jawaban)) {
    $jawaban[$row_j['id_soal']] = $row_j['jawaban'];
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>eksplorasi-data</title>
    <link rel="stylesheet" href="css/topside.css" />
    <link rel="stylesheet" href="css/eksplorasi-layout.css" />
    <link rel="stylesheet" href="css/eksplorasi-data.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">

  </head>
  <body>
    <div class="container">
      <div class="sidebar">
        <div class="logo">
          <button id="toggleBtn"><i class="fas fa-bars"></i></button>
          <div class="logo-container">
            <img src="assets/logo.png" alt="Logo" class="logo-img">
            <span class="logo-text">PROGRESO</span>
          </div>
        </div>
        <ul class="menu">
          <li><a href="beranda.php"><i class="fas fa-home"></i><span>Beranda</span></a></li>
          <li><a href="LKPD.php"><i class="fas fa-file-alt"></i> <span>LKPD</span></a></li>
          <li><a href="modul.php"><i class="fas fa-book"></i> <span>Materi Tambahan</span></a></li>
          <li><a href="test.php"><i class="fas fa-clipboard-check"></i> <span>Tes Pemahaman</span></a></li>
          <li><a href="pengguna.php"><i class="fas fa-user-circle"></i> <span>Pengguna</span></a></li>
          <li><a href="bantuan.php"><i class="fas fa-question-circle"></i> <span>Perlu Bantuan</span></a></li>
        </ul>
        <ul class="menu menu-bawah">
          <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i><span>Keluar</a></li>
        </ul>
      </div>

      <!-- Main Area -->
      <div class="main-content">

        <!-- Topbar -->
        <div class="topbar">
          <div class="title"></div>
          <!--  <div class="topbar-right">-->
          <!--  <div class="search-box">-->
          <!--    <i class="fas fa-search"></i>-->
          <!--    <input type="text" placeholder="Cari modul atau topik...">-->
          <!--  </div>-->
          <!--  <div class="topbar-icons">-->
          <!--    <i class="fas fa-bell"></i>-->
          <!--  </div>-->
          <!--</div>-->
        </div>

        <!-- Konten -->
        <!-- Problem Statement index (php) -->
        <section class="explore-section">
          <div class="explore-container">
            <div class="section-title">
              <h2>Tahap 3</h2>
              <p>Perhatikan visualisasi di bawah ini. Visualisasi ini akan membantu Anda memahami konsep atau data dengan lebih mudah dan cepat.</p>
            </div>
            <div class="progress-bar-container">
              <div class="progress-text">Tahap 3 dari 6: Pengumpulan Data (40%)</div>
                <div class="progress-bar">
                <div class="progress-fill" style="width: 40%;"></div>
              </div>
              <!-- Placeholder area untuk 3D Object -->

              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
                <!--<div class="three-d-area">-->
                <!--    <div class="three-d-object">-->
                <!--      <iframe title="Router 3D"-->
                <!--          frameborder="0"-->
                <!--          allowfullscreen-->
                <!--          mozallowfullscreen="true"-->
                <!--          webkitallowfullscreen="true"-->
                <!--          allow="autoplay; fullscreen; xr-spatial-tracking"-->
                <!--          src="https://sketchfab.com/models/xxxxxxxxx/embed"-->
                <!--          style="width: 100%; height: 400px; border-radius: 14px;">-->
                <!--      </iframe>-->
                <!--      <p>Model Router Interaktif</p>-->
                <!--    </div>-->
                <!--</div>-->

              <!-- Informasi hasil klik -->
            <div class="info-box info-box-flex">
              <h2>klik teks warna biru berikut untuk membuka eksplorasi atau bisa menggunakan pencaharian langsung di google:<h2>
              <a href="modul.php" class="info-link">
                >> Gunakan materi tambahan berikut sebagai referensi saat menjawab soal berikutnya
              </a>

              <div class="google-widget-inline">
                <input type="text" id="googleQuery" placeholder="Cari di Google...">
                <button onclick="searchGoogle()">
                  <i class="fab fa-google"></i> Cari
                </button>
              </div>
            </div>



              <!-- Tombol Filter Search Google -->
              <!-- <div class="google-search-box">
                <h3>Butuh referensi lain?</h3>
                <div class="search-google">
                  <input type="text" id="googleQuery" placeholder="Cari di Google...">
                  <button onclick="searchGoogle()">Cari</button>
                </div>
              </div> -->
              <!-- <div class="info-box" id="infoBox">Gunakan materi tambahan berikut sebagai referensi saat menjawab soal berikutnya</div> -->
              <form action="jawaban-data.php" method="post">
                <input type="hidden" name="id_materi" value="<?= $id_materi ?>">
            <?php
                $no = 1;
                $data = mysqli_query($conn, "SELECT * FROM observasi WHERE id_materi = $id_materi");
                if (mysqli_num_rows($data) > 0):
                  while($row = mysqli_fetch_array($data)):
              ?>  
              <div class="question-card">
                <img src="../guru/<?= $row['gambar'] ?>"  style="max-width: 20%; border-radius: 8px; margin-bottom: 16px;">
                <h3><?= $row['pertanyaan'] ?></h3>
                <input type="hidden" name="id_soal[]" value="<?= $row['id'] ?>">
                <textarea class="essay-input" 
                name="jawaban[<?= $row['id'] ?>]" 
                rows="3" 
                placeholder="Tulis pendapatmu di sini..."><?= htmlspecialchars($jawaban[$row['id']] ?? '') ?></textarea>
              </div>
              <?php
                  endwhile;
                else:
              ?>
                <tr>
                  <td colspan="5" style="text-align:center;">Belum ada data Soal.</td>
                </tr>
              <?php endif; ?>
            <button type="submit" class="btn-primary2" onclick="myFunction()">Submit</button>
              </form>

              <!-- Teori singkat -->
              <!-- <div class="question-card">
                <h3>Teori Singkat</h3>
                <p><strong>IP Address</strong> adalah alamat identitas perangkat dalam jaringan. <br>
                <strong>Jaringan lokal (LAN)</strong> menghubungkan perangkat dalam area terbatas, sedangkan <strong>Internet</strong> menghubungkan berbagai LAN secara global.</p>
                <button class="btn-primary" onclick="window.location.href='materi.php'">Baca Teori Lengkap</button>
              </div> -->

            </div>
            <div class="submit">
              <a href="eksplorasi-processing.php?id_materi=<?= $id_materi?>" class="btn-primary2">Lanjutkan</a>
            </div>
          </div>
        </section>
      </div>
    </div>

    <script>
      function searchGoogle() {
        const query = document.getElementById('googleQuery').value.trim();
        if (query !== "") {
          const url = "https://www.google.com/search?q=" + encodeURIComponent(query);
          window.open(url, "_blank");
        } else {
          alert("Masukkan kata kunci dulu ya!");
        }
      }
    </script>
    <script>
      function myFunction() {
      alert("Jawaban Berhasil di Submit!");
      }
      </script>


    <script>
      // Contoh untuk halaman Problem Statement
      document.addEventListener("DOMContentLoaded", function () {
      // Ganti angka di sini sesuai tahapnya
      localStorage.setItem("discoveryProgress", "40");

      // Kalau ingin juga update progress bar lokal (di halaman ini)
      const progressFill = document.querySelector(".progress-fill");
      const progressText = document.querySelector(".progress-text");
      if (progressFill && progressText) {
      progressFill.style.width = "40%";
      progressText.innerText = "Tahap 3 dari 6: Pengumpulan Data (40%)";
      }
      });
    </script>
    <script src="js/script.js"></script>
  </body>
</html>
