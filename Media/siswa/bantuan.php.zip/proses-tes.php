<?php
include("../dbconn/dbconn.php");
session_start();

$id_siswa = $_SESSION['id_user'];
$id_kategori = $_POST['id_kategori'];

// Ambil semua soal dari kategori
$sql = "SELECT id_tes, jawaban_benar FROM tes WHERE id_kategori = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_kategori);
$stmt->execute();
$result = $stmt->get_result();

$total_score = 0;
$total_questions = $result->num_rows;

// Hitung skor siswa
while ($row = $result->fetch_assoc()) {
    $id_pertanyaan = $row['id_tes'];
    $jawaban_benar = $row['jawaban_benar'];
    $jawaban_siswa = $_POST["question$id_pertanyaan"] ?? '';

    if ($jawaban_siswa === $jawaban_benar) {
        $total_score++;
    }
}

// Hitung skor persen
$percentage_score = ($total_questions > 0) ? round(($total_score / $total_questions) * 100, 2) : 0;

// Simpan hasil ke tabel hasil_tes saja
$sql_hasil = "INSERT INTO hasil_tes (id_siswa, id_kategori, skor, status, waktu_submit) VALUES (?, ?, ?, ?, ?)";
$stmt_hasil = $conn->prepare($sql_hasil);

$status = 1;
$tanggal = date('Y-m-d H:i:s');
$stmt_hasil->bind_param("iiiss", $id_siswa, $id_kategori, $percentage_score, $status, $tanggal);
$stmt_hasil->execute();

header("Location: test.php");
exit();
?>
